import { Component, EventEmitter, Output, SimpleChanges } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MyLibService } from '../my-lib.service';

interface BidDetail {
  bid_No: number;
  title_Deed_No: string;
  certificate_No: string;
  total_Min_Bid_Price: number;
  location: string;
  size: number;
}

@Component({
  selector: 'lib-bid-detail',
  templateUrl: './bid-detail.component.html',
  styleUrls: ['./bid-detail.component.css']
})
export class BidDetailComponent {
  highlighted;
  maxWidth: string = "1400px";
  maxheight: string;
  selectedTab = 0;
  @Output() completed=new EventEmitter()
  tab1;
  displayReadyLease:any
  ismodaEnable:boolean;
  tab2;
  bidDetail: BidDetail = {
    bid_No: 0,
    title_Deed_No: '',
    certificate_No: '',
    total_Min_Bid_Price: 0,
    location: '',
    size: 0
  };
  leaseReadyForBids: any;
  constructor(
    private sanitizer: DomSanitizer,
  private apiService:MyLibService) { }
  bidDetails: BidDetail[] = [];
  plan_Document: any;
  isDone: boolean;
  isEdit: boolean;
  Public_bid_No: any;
  ngOnInit() {
  this.getReadyLease()
  }
  ngOnChanges(changes: SimpleChanges) {
    console.log('changes',changes);
    
    // this.fetchData()
 
}
  submitForm() {
   this.apiService.insertBid_Detail(this.bidDetail).subscribe((res:any)=>{
    console.log(res);
    
    this.resetForm();
    this.isDone=true
   })
  }
  onSelectReadyLease(bid){
    this.bidDetail.title_Deed_No=bid.title_Deed_No
    this.bidDetail.certificate_No=bid.cerficate_ID
  }
  getReadyLease(){
    this.apiService.getView_Lease_Ready_For_Bid().subscribe((Ready_Lease:any)=>{
      this.leaseReadyForBids=Ready_Lease
    })
  }
  tabChanged(e) { 
    console.log(e.index);
    if (e.index == 0) {
      this.tab1 = true;
      this.tab2 = false;
    } else if (e.index == 1) {
      this.tab1 = false;
      this.tab2 = true;
    }
  }
  Next(event){
    this.selectedTab = 1
    this.Public_bid_No=event
    this.bidDetail.bid_No=this.Public_bid_No
    this.fetchData(event)
  }
  fetchData(bid_no){
    this.apiService.getBid_DetailById(bid_no).subscribe((Bid_detail:any)=>{
      this.bidDetails=Bid_detail.procBid_Details
    })
  }
  update(){
this.apiService.updateBid_Detail(this.bidDetail).subscribe((res:any)=>{

  this.isDone=true
})
  }
  onRowSelect(plan){
    this.bidDetail=plan
    this.isEdit=true 
    this.displayReadyLease=false
  }
  done(){
    this.completed.emit()
  }
  acceptLatLong(event){
    console.log('event',event);
    this.ismodaEnable=false
    this.bidDetail.location='https://www.google.com/maps?q='+event.lat+','+event.lng
  }
  openGoogleMaps(value): void {
    // const url = `https://www.google.com/maps?q=${lat},${lng}`;
    window.open(value, '_blank');
  }
  resetForm() {
    this.bidDetail = {
      bid_No: 0,
      title_Deed_No: '',
      certificate_No: '',
      total_Min_Bid_Price: 0,
      location: '',
      size: 0
    };
  }
}
