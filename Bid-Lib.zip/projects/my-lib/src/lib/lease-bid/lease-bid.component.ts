import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MyLibService } from '../my-lib.service';

@Component({
  selector: 'lib-lease-bid',
  templateUrl: './lease-bid.component.html',
  styleUrls: ['./lease-bid.component.css']
})
export class LeaseBidComponent implements OnInit {
  mimeType: any;
  fileupload: string;
  @Output() next = new EventEmitter();
  highlighted;
  uploadedDocumnet: boolean;
  uploadcontract: boolean;
  uploaded: boolean;
  documentupload: any;
  leaseBids: any;
  displayplan:boolean
  yearlyBidPlans:any
  isEdit: boolean;
  isDone: boolean;
  opening_TimeEn: string;
  closing_TimeEn:any
  closing_TimeET:any
  opening_TimeET:any
  extracted: { date: any; time: any; };
  bidType: any;
  BidTypeLookup: any[] = [];
  plan_id: any;
  constructor(
    private sanitizer: DomSanitizer,
  private apiService:MyLibService) { }
  formData = {
    bid_No: 0,
    bid_Plan_ID: '',
    bid_Type: '',
    bid_Doc_Price: 0,
    bid_Document: '',
    adnace_Payment_grad: '',
    bid_prices_graid: '',
    published_Date: '',
    opening_Date: '',
    closeding_Date: '',
    opining_Date_ET: '',
    closeding_Date_ET: ''
  };
  
  submitForm() {
    // Handle form submission logic here
this.apiService.insertLease_Bid(this.formData).subscribe((res:any)=>{
  console.log(res);
  
})
    this.isDone=true
  }
  
  ngOnInit() {
    this.getBid_type()
    this.fetchData()
    this.getView_Yearly_Bid_Plan()
  }
  getBid_type() {
    this.apiService.getBid_type().subscribe(
      (response: any) => {
        console.log('API Response:', response);
        this.BidTypeLookup = response;
        console.log('Processed BidTypeLookup:', this.BidTypeLookup);
      },
      (error) => {
        console.error('Error fetching bid types:', error);
      }
    );
  }
  getView_Yearly_Bid_Plan(){
    this.apiService.getView_Yearly_Bid_Plan().subscribe((View_Yearly_Bid_Plan:any)=>{
      this.yearlyBidPlans=View_Yearly_Bid_Plan
    })
  }
  selectPlan(plan){
    this.displayplan=false
    this.plan_id=plan.year
    this.formData.bid_Plan_ID=plan.plan_ID
  }
  update(){
    this.apiService.updateLease_Bid(this.formData).subscribe((res:any)=>{
      console.log(res);
      
    })
    this.isDone=true
  }
  fetchData(){
    this.apiService.getView_Lease_Bid().subscribe((Lease_bid:any)=>{
      this.leaseBids=Lease_bid
    })
  }
  onRowSelect(plan){
    this.formData=plan
    this.isEdit=true 
  }
  done(){
    // this.completed.emit()
  }
  Next(){
this.next.emit(this.formData.bid_No)
  }
  checkTime() {
  this.formData.opening_Date= combineDate(this.formData.opening_Date,this.opening_TimeEn)
  this.extracted=extractDateTime(this.formData.opening_Date)
  console.log('Combined DateTime:',this.extracted, this.formData.opening_Date);

   
  
  }
  upload(event:any) {
     
    if(event.files[0].size > 200000){
      //  const toast = this.notificationsService.error('error', 'maximum file size is 3MB');
    }else{
      this.Uploader(event.files[0]);
      console.log('event', event);
      console.log('files', event.files); 
    }
  
  
  }
  Uploader(File: File) {
    console.log('File ', File);
    let base64file: string | ArrayBuffer | null;
    let fullbase64: string | null = null;
    const reader = new FileReader();
    reader.readAsDataURL(File);
  
    reader.addEventListener('loadend', (e) => {
      base64file = reader.result;
  
      if (typeof base64file === 'string') {
        fullbase64 = base64file;
        const re = /base64,/gi;
        base64file = base64file.replace(re, '');
        base64file = base64file.split(';')[1];
  
        let type = File.type !== '' ? File.type : this.extractExtensionFromFileName(File.name);
        let base64FileData = btoa(JSON.stringify({
          type,
          data: base64file
        }));
  console.log('base64FileData',base64FileData);
  this.uploaded=true
  
        // const toast = this.notificationsService.success('Success', 'Uploaded successfully');
        this.formData.bid_Document = base64FileData;
        this.documentupload = base64FileData;
        this.previewdocumnet(base64FileData)
      } else {
        console.error('File could not be read as a string.');
      }
    });
  }
  extractExtensionFromFileName(fileName:any) {
    if (fileName) {
      let fileNameSegment = (fileName as string).split('.');
      return `application/${fileNameSegment[fileNameSegment.length - 1]}`;
    }
    return '';
  }
  previewdocumnet(file:any){
  
    try {
     
     let fileData = JSON.parse(window.atob(file));
      let { type, data } = fileData;
      this.mimeType=type
      this.fileupload= "data:" + type + ";base64, " + data;
      this.uploadedDocumnet=true
      this.uploadcontract=false
     
      this.documentupload= this.sanitizer.bypassSecurityTrustResourceUrl(
               this.fileupload
             );
      console.log(this.documentupload);
  }
           catch (e) {
             console.error(e);
           }
  }
}
function extractDateTime(dateTime) {
  if (dateTime) {
    const Date={
      date:dateTime.substring(0, 10),
      time:dateTime.substring(11, 16)
    }
    return Date// Adjust length according to your time format
  }
}
function combineDate(date,time){
  if (date && time) {
    // Combine date and time
    const combinedDateTime = date + 'T' + time + ':00';
    return combinedDateTime
    console.log('Combined DateTime:', combinedDateTime);

   
  }
}