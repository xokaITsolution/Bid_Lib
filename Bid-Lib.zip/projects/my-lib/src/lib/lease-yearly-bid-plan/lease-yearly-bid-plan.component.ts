import { Component, EventEmitter, Output } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MyLibService } from '../my-lib.service';

interface YearlyBidPlan {
  plan_ID: number;
  year: number;
  land_use: string;
  bid_Type: string;
  building_Use: string;
  plot_Qty: number;
  total_Sizeof_plot: number;
  bid_Opning_Date: string;
  bid_Start_Date: string;
  bid_Enddate: string;
  prepared_by: string;
  approved_by: string;
  is_published: boolean;
  min_bid_Plot: number;
}

@Component({
  selector: 'lib-lease-yearly-bid-plan',
  templateUrl: './lease-yearly-bid-plan.component.html',
  styleUrls: ['./lease-yearly-bid-plan.component.css']
})
export class LeaseYearlyBidPlanComponent {
  displayDeed:boolean
  BidTypeLookup: any[] = [];
  @Output() completed= new EventEmitter()
  highlighted;
  yearlyBidPlan: YearlyBidPlan = {
    plan_ID: null,
    year: 0,
    land_use: '',
    bid_Type: '',
    building_Use: '',
    plot_Qty: 0,
    total_Sizeof_plot: 0,
    bid_Opning_Date: '',
    bid_Start_Date: '',
    bid_Enddate: '',
    prepared_by: '',
    approved_by: '',
    is_published: false,
    min_bid_Plot: 0
  };
  BuildingUseLookup: any;
  LandUseLookup: any;
  constructor(
    private sanitizer: DomSanitizer,
  private apiService:MyLibService) { }
  yearlyBidPlans: YearlyBidPlan[] = [];
  isEdit: boolean;
  isDone: boolean;
  ngOnInit() { 
  
    this.getBid_type() 
    this.getView_propertyUse()
    this.getPlotLandUseLookUP()
    this.getView_Yearly_Bid_Plan()
    this.yearlyBidPlan.bid_Type = '9de9b9ab-34c3-4daf-a1a6-82d32c8b94ae';
    this.yearlyBidPlan.bid_Type = String(this.yearlyBidPlan.bid_Type);
    this.BidTypeLookup = this.BidTypeLookup.map(b => ({ ...b, bid_Type_Id: String(b.bid_Type_Id) }));
    console.log('Initialized bid_Type:', this.yearlyBidPlan.bid_Type);
    console.log('BidTypeLookup:', this.BidTypeLookup);
  }
  submitForm() {
    this.apiService.inseetLease_Yearly_Bid_Plan(this.yearlyBidPlan).
    subscribe((value:any)=>{
      console.log(value);
      
    })
    // this.resetForm();
this.isDone=true
  }
  getView_Yearly_Bid_Plan(){
    this.apiService.getView_Yearly_Bid_Plan().subscribe((View_Yearly_Bid_Plan:any)=>{
      this.yearlyBidPlans=View_Yearly_Bid_Plan
    })
  }
  getBid_type() {  
    this.apiService.getBid_type().subscribe(
      (response: any) => {
        console.log('API Response:', response);
        this.BidTypeLookup = response;
        console.log('Processed BidTypeLookup:', this.BidTypeLookup);
      },
      (error) => {
        console.error('Error fetching bid types:', error);
      }
    );
  }
  getView_propertyUse(){
    this.apiService.getView_propertyUse().subscribe((Building_Use:any)=>{
     
        console.log('API Response:', Building_Use);
        this.BuildingUseLookup = Building_Use;
        console.log('Processed BidTypeLookup:', this.BuildingUseLookup);
      },
      (error) => {
        console.error('Error fetching bid types:', error);
      
    })
  }
  getPlotLandUseLookUP() {
    this.apiService.getPlotLandUseLookUP().subscribe(
      (PlotLandUseLookUP) => {
        this.LandUseLookup = PlotLandUseLookUP;
        this.LandUseLookup = Object.assign([], this.LandUseLookup.list);
        console.log("PlotLandUseLookUP", PlotLandUseLookUP);
      },
      (error) => {
        console.log("error");
      }
    );
  }

  dialog(){
    this.displayDeed=true
  }
  update(){
    this.isDone=true
  }
  selectPlan(plan){
    this.yearlyBidPlan=plan
  console.log('  this.yearlyBidPlan.bid_Type',  this.yearlyBidPlan.bid_Type);
  
    this.isEdit=true 
  }
  done(){
    this.completed.emit()
  }
  addNew(){
    this.yearlyBidPlan= {
      plan_ID: null,
      year: 0,
      land_use: '',
      bid_Type: '',
      building_Use: '',
      plot_Qty: 0,
      total_Sizeof_plot: 0,
      bid_Opning_Date: '',
      bid_Start_Date: '',
      bid_Enddate: '',
      prepared_by: '',
      approved_by: '',
      is_published: false,
      min_bid_Plot: 0
    }; 
  }
}
function generateGuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
  });
}